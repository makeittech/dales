<?php /* Template Name: Careers */ ?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>
	<div id="primary" <?php generate_content_class();?>>
		<main id="main" <?php generate_main_class(); ?>>
			<?php
			/**
			 * generate_before_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_before_main_content' );

			while ( have_posts() ) : the_post();

				get_template_part( 'content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || '0' != get_comments_number() ) : ?>

					<div class="comments-area">
						<?php comments_template(); ?>
					</div>

				<?php endif;

			endwhile;

			/**
			 * generate_after_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_after_main_content' );
			?>
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();
	?>
	<div class="container">
		<form method="POST" class="email_fails" name="email_form_with_php" enctype="multipart/form-data"> 
			<label for='uploaded_file'>Select A File To Upload:</label>
			<input type="file" name="uploaded_file">

			<input type="submit" value="Submit" name='submit'>
		</form>
	</div>
	<?php 
		//Get the uploaded file information
		$errors = '';
		$name_of_uploaded_file = basename($_FILES['uploaded_file']['name']);
		echo $name_of_uploaded_file;
		echo "<br>";
		//get the file extension of the file
		$type_of_uploaded_file = substr($name_of_uploaded_file, strrpos($name_of_uploaded_file, '.') + 1);
		echo $type_of_uploaded_file;
		echo "<br>";
		$size_of_uploaded_file = $_FILES["uploaded_file"]["size"]/1024;//size in KBs

		//Settings
		$max_allowed_file_size = 100; // size in KB
		$allowed_extensions = array("pdf", "jpg", "jpeg", "doc", "docx");

		//Validations
		if($size_of_uploaded_file > $max_allowed_file_size )
		{
		  $errors = "\n Size of file should be less than $max_allowed_file_size";
		}

		//------ Validate the file extension -----
		$allowed_ext = false;
		for($i=0; $i<sizeof($allowed_extensions); $i++)
		{
		  if(strcasecmp($allowed_extensions[$i],$type_of_uploaded_file) == 0)
		  {
		    $allowed_ext = true;
		  }
		}

		if(!$allowed_ext)
		{
		  $errors = "\n The uploaded file is not supported file type. ".
		  " Only the following file types are supported: ".implode(',',$allowed_extensions);
		}
		//copy the temp. uploaded file to uploads folder
		// $path_of_uploaded_file = $upload_folder . $name_of_uploaded_file;
		// $tmp_path = $_FILES["uploaded_file"]["tmp_name"];

		// if(is_uploaded_file($tmp_path))
		// {
		//   if(!copy($tmp_path,$path_of_uploaded_file))
		//   {
		//     $errors .= '\n error while copying the uploaded file';
		//   }
		// }
		echo '<pre>';
		print_r($_FILES);
		echo "</pre>";
		echo $_FILES['uploaded_file']['tmp_name'];
		echo "<br>";
		//$temp_file = file_get_contents($_FILES['uploaded_file']['tmp_name']);

		//var_dump($temp_file);

		//$attachments = array(WP_CONTENT_DIR . '/uploads/attach.zip');
		//$headers = 'From: My Name <myname@mydomain.com>' . "\r\n";

		//wp_mail('test@test.com', 'Тема', 'Содержание', $headers, $attachments);

		if($errors != ''){
			echo $errors;
		}
		print_r($type_of_uploaded_file);
	 ?>
<?php get_footer(); ?>